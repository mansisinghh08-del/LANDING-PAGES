import React from 'react';

export const ProblemSection: React.FC = () => {
  const painPoints = [
    {
      title: "Peak Festival Unavailability",
      description:
        "Between Devuthani Ekadashi and Kartik Purnima, experienced Vedic Pandits get booked out days in advance. Many families are left scrambling at the eleventh hour or settling for unverified priests who rush the ceremony.",
      badge: "Festival Crunch",
      icon: "⏳",
    },
    {
      title: "Confusion Over Samagri & Preparation",
      description:
        "Families frequently struggle to distinguish between simple household items and ceremonial wedding essentials—such as the sugarcane mandap (ganne ka mandap), suhaag chunri, sacred gathbandhan, and kalash items.",
      badge: "Preparation Stress",
      icon: "🧺",
    },
    {
      title: "Rushed Rituals Without Explanation",
      description:
        "Too often, ceremonies are mechanically hurried through without pausing to explain the profound Vedic symbolism of the Sankalp, Kanyadaan, and Tulsi-Shaligram union to children and elders participating in the home.",
      badge: "Devotional Disconnect",
      icon: "📜",
    },
    {
      title: "Unclear Pricing & Last-Minute Surprises",
      description:
        "Generic booking apps demand upfront non-refundable payments before confirming Pandit travel feasibility, duration, or samagri scope—leading to uncomfortable post-puja discussions or unexpected extra costs.",
      badge: "Booking Uncertainty",
      icon: "🏷️",
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-stone-50/70 border-b border-orange-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-orange-700 bg-orange-100/70 px-3.5 py-1.5 rounded-full border border-orange-200">
            Common Festive Challenges
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-4 mb-4 tracking-tight">
            Why Families Struggle to Arrange a Peaceful Tulsi Vivah Puja During Kartik Month
          </h2>
          <p className="text-stone-600 text-base leading-relaxed">
            The sacred Kartik month is the most auspicious window for invoking the blessings of Lord Vishnu and Tulsi Devi, yet organizing a serene home ceremony often turns overwhelming without proper coordination.
          </p>
        </div>

        {/* 4 Pain Point Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {painPoints.map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-6 sm:p-7 border border-orange-100/80 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-orange-50 border border-orange-200 flex items-center justify-center text-2xl shrink-0 group-hover:scale-110 transition-transform">
                  {item.icon}
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-stone-100 text-stone-600">
                      {item.badge}
                    </span>
                  </div>
                  <h3 className="font-heading text-lg sm:text-xl font-bold text-stone-800">
                    {item.title}
                  </h3>
                  <p className="text-sm text-stone-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Transition Bridge */}
        <div className="mt-12 text-center">
          <p className="text-sm font-medium text-amber-900 inline-flex items-center gap-2 bg-amber-50 px-4 py-2 rounded-full border border-amber-200">
            <span>💡</span>
            <span>That is why Shastriya Vidhan introduced our <strong>Request-First Vedic Standard</strong>.</span>
          </p>
        </div>
      </div>
    </section>
  );
};
export default ProblemSection;
