import React from 'react';
import type { Metadata } from 'next';
import SchemaMarkup from '@/components/SchemaMarkup';
import TulsiVivahClient from './TulsiVivahClient';

export const metadata: Metadata = {
  title: 'Book Pandit for Tulsi Vivah Puja | Home & Online | Shastriya Vidhan',
  description: 'Book a verified Vedic Pandit Ji for Tulsi Vivah Puja in Noida, Delhi, Gurugram or Online. Clear samagri checklist, vidhi guidance & quote clarity before payment.',
  alternates: {
    canonical: 'https://www.shastriyavidhan.com/book-pandit-ji-online-for-tulsi-vivah',
  },
  openGraph: {
    title: 'Book Pandit for Tulsi Vivah Puja | Home & Online | Shastriya Vidhan',
    description: 'Book a verified Vedic Pandit Ji for Tulsi Vivah Puja in Noida, Delhi, Gurugram or Online. Clear samagri checklist, vidhi guidance & quote clarity before payment.',
    url: 'https://www.shastriyavidhan.com/book-pandit-ji-online-for-tulsi-vivah',
    siteName: 'Shastriya Vidhan',
    images: [
      {
        url: 'https://www.shastriyavidhan.com/images/tulsi-vivah.webp',
        width: 1200,
        height: 630,
        alt: 'Book Pandit Ji Online for Tulsi Vivah Puja - Authentic Tulsi Shaligram Vivah Arrangement',
      },
    ],
    locale: 'en_IN',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Book Pandit for Tulsi Vivah Puja | Home & Online | Shastriya Vidhan',
    description: 'Book a verified Vedic Pandit Ji for Tulsi Vivah Puja in Noida, Delhi, Gurugram or Online. Clear samagri checklist, vidhi guidance & quote clarity before payment.',
    images: ['https://www.shastriyavidhan.com/images/tulsi-vivah.webp'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
};

export default function TulsiVivahPage() {
  return (
    <>
      {/* JSON-LD Schemas: Service, FAQPage (all 12 FAQs), BreadcrumbList */}
      <SchemaMarkup />

      {/* Complete Interactive Page Architecture */}
      <TulsiVivahClient />
    </>
  );
}
