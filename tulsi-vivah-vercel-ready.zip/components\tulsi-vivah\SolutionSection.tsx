import React from 'react';

export const SolutionSection: React.FC = () => {
  const pillars = [
    {
      step: "01",
      title: "Reviewed Pandit Ji Assignment",
      subtitle: "Guided by Acharya Sursain Brijwasi's Standards",
      description:
        "Every booking request is personally reviewed and matched with an authentic, Gurukul-trained Vedic priest based on your family's language preference (Hindi, Sanskrit, or English), regional customs, and exact sector location across Noida, Delhi, and Gurugram.",
      icon: "🪔",
    },
    {
      step: "02",
      title: "Upfront Samagri Responsibility",
      subtitle: "Never Guess What to Prepare",
      description:
        "Before confirming, we clearly demarcate simple household items (fruits, ghee, flowers) from ceremonial wedding items (ganne ka mandap, red chunri, Shaligram arrangement). You know exactly what is arranged by Pandit Ji and what to keep ready at home.",
      icon: "✨",
    },
    {
      step: "03",
      title: "Quote Review Before Payment",
      subtitle: "Zero Blind Booking Or Upfront Pressure",
      description:
        "You never pay blindly on our website. Our booking desk manually confirms the date, muhurat timing window, travel feasibility in Delhi NCR, and provides an itemized quote first. Pay only when you are 100% satisfied with the arrangement.",
      icon: "🛡️",
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-gradient-to-b from-white via-amber-50/20 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-amber-800 bg-amber-100/80 px-3.5 py-1.5 rounded-full border border-amber-300">
            The Shastriya Vidhan Standard
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-4 mb-4 tracking-tight">
            A Calmer, Transparent Way to Book Pandit Ji for Tulsi Vivah Puja
          </h2>
          <p className="text-stone-600 text-base leading-relaxed">
            We replaced automated booking portals with human devotion and Vedic accountability. Experience a serene, respectful process designed around your family’s peace of mind.
          </p>
        </div>

        {/* 3 Core Solution Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pillars.map((pillar, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-7 border border-orange-200/90 shadow-sm hover:shadow-lg transition-all relative flex flex-col justify-between group hover:-translate-y-1"
            >
              <div>
                {/* Step Pill & Icon */}
                <div className="flex items-center justify-between mb-5">
                  <span className="text-2xl">{pillar.icon}</span>
                  <span className="font-heading text-sm font-bold px-3 py-1 rounded-full bg-orange-100 text-orange-800 border border-orange-200">
                    Step {pillar.step}
                  </span>
                </div>

                <h3 className="font-heading text-xl font-bold text-stone-900 mb-1">
                  {pillar.title}
                </h3>
                <div className="text-xs font-semibold text-amber-700 uppercase tracking-wider mb-3">
                  {pillar.subtitle}
                </div>
                <p className="text-sm text-stone-600 leading-relaxed">
                  {pillar.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-stone-100 flex items-center text-xs font-medium text-orange-700 group-hover:text-orange-800">
                <span>Verified Shastriya Standard</span>
                <span className="ml-1.5 font-bold">✓</span>
              </div>
            </div>
          ))}
        </div>

        {/* Quick CTA strip */}
        <div className="mt-12 text-center">
          <a
            href="#book-pandit-ji"
            className="inline-flex items-center gap-2 text-sm sm:text-base font-bold text-orange-700 hover:text-orange-800 bg-orange-50 hover:bg-orange-100 border border-orange-200 px-6 py-3 rounded-full transition-all"
          >
            <span>Experience the difference — Request your Tulsi Vivah quote</span>
            <span>→</span>
          </a>
        </div>

      </div>
    </section>
  );
};
export default SolutionSection;
