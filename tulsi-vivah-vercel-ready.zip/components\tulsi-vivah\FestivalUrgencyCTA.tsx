import React from 'react';

export const FestivalUrgencyCTA: React.FC = () => {
  return (
    <section className="py-16 sm:py-20 bg-gradient-to-r from-stone-900 via-amber-950 to-stone-900 text-white relative overflow-hidden">
      {/* Decorative background aura */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-600/20 via-transparent to-transparent pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-600/30 border border-orange-400/50 text-orange-300 text-xs sm:text-sm font-semibold mb-6">
          <span>✨</span>
          <span>Kartik Month Festive Booking Window</span>
        </div>

        <h2 className="font-heading text-2xl sm:text-3xl lg:text-5xl font-bold tracking-tight mb-4 text-stone-100">
          Devuthani Ekadashi &amp; Kartik Purnima Slots Fill Up Rapidly
        </h2>

        <p className="text-stone-300 text-sm sm:text-lg max-w-2xl mx-auto leading-relaxed mb-8">
          Because authentic Gurukul-trained Vedic Pandits in Noida, Delhi, and Gurugram are in exceptionally high demand during the holy wedding season, we strongly encourage reserving your muhurat window early.
        </p>

        {/* Value Reassurance */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs sm:text-sm text-stone-300 mb-8 font-medium">
          <span className="flex items-center gap-1.5">
            <span className="text-emerald-400">✓</span> Free Manual Schedule Check
          </span>
          <span className="flex items-center gap-1.5">
            <span className="text-emerald-400">✓</span> No Advance Payment Before Quote Review
          </span>
          <span className="flex items-center gap-1.5">
            <span className="text-emerald-400">✓</span> Clear Samagri Responsibility
          </span>
        </div>

        {/* Dual CTA buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#book-pandit-ji"
            className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-4 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white font-bold text-base shadow-xl hover:shadow-2xl transition-all min-h-[48px]"
          >
            <span>Lock Your Preferred Muhurat Slot</span>
            <span className="ml-2 font-bold">→</span>
          </a>

          <a
            href="https://wa.me/917599340430?text=Namaste%20Shastriya%20Vidhan%2C%20I%20want%20to%20check%20Pandit%20Ji%20availability%20for%20Tulsi%20Vivah%20Puja."
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center px-7 py-4 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-semibold text-base shadow-lg transition-all min-h-[48px]"
          >
            <span className="mr-2">💬</span>
            <span>Check Availability on WhatsApp</span>
          </a>
        </div>

        <p className="text-xs text-stone-400 mt-6">
          Direct Booking Desk: <a href="tel:+917599340430" className="text-orange-300 hover:underline font-semibold">+91 75993 40430</a> (7:00 AM – 9:30 PM)
        </p>
      </div>
    </section>
  );
};
export default FestivalUrgencyCTA;
