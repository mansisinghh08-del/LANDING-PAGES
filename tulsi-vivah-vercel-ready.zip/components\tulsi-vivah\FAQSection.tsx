import React, { useState } from 'react';

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: "When is Tulsi Vivah Puja performed in Kartik month (Devuthani Ekadashi to Kartik Purnima)?",
      a: "Tulsi Vivah is traditionally observed during Shukla Paksha of the holy Kartik month. The observance begins on Devuthani Ekadashi (also called Prabodhini Ekadashi, marking the divine awakening of Lord Vishnu after Chaturmas) and continues through Dwadashi up to Kartik Purnima. Families can choose an auspicious muhurat window across any of these sacred dates depending on their family customs and convenience."
    },
    {
      q: "How do I book a Pandit Ji for Tulsi Vivah Puja at home in Noida, Delhi, or Gurugram?",
      a: "Booking is simple and risk-free: Submit our 4-step Priority Request Form selecting Tulsi Vivah Puja, your location, and preferred date. Our booking desk verifies Gurukul-trained Pandit Ji availability, confirms travel logistics to your sector or society, shares the upfront samagri checklist, and gives you a transparent quote. Once you review and approve the quote, your booking is confirmed."
    },
    {
      q: "Do I have to pay immediately when submitting the request form?",
      a: "No, absolutely not. Under 'The Shastriya Vidhan Standard,' we follow a strict Request-First policy. Submitting your priority request is 100% free with zero payment obligation. We first verify Pandit Ji availability, travel feasibility, and exact requirements. You only pay once you have reviewed and approved the transparent quote."
    },
    {
      q: "What is the typical duration of the Tulsi Vivah ceremony? (60–120 minutes)",
      a: "A traditional Shastrokt Tulsi Vivah ceremony typically takes between 60 to 120 minutes. This includes Swasti Vachan, Sankalp, Ganesh-Gauri worship, Kalash sthapana, Shaligram abhishek, sacred wedding rituals (gathbandhan, kanyadaan, mangalashtak), Tulsi vivah katha recitation, and concluding family aarti. If you choose an optional low-smoke havan, it may extend slightly."
    },
    {
      q: "Who arranges the Tulsi Vivah Puja Samagri, Shaligram Ji, and Ganne ka Mandap?",
      a: "We offer complete flexibility: In Path A (Guidance Only), the family prepares the items using our itemized checklist. In Path B (Coordinated Samagri Support), Pandit Ji brings the specialized ritual kit including sacred suhaag items, gathbandhan cloth, and ceremonial essentials. Families provide the live Tulsi plant; if your home does not have a Shaligram Shila, Pandit Ji will bring a sanctified Shaligram Ji for the ceremony."
    },
    {
      q: "How much does it cost to book a Pandit Ji for Tulsi Vivah?",
      a: "Our quotes are transparent and customized based on your location (Noida, Delhi, Gurugram, Ghaziabad, or Online), ceremony duration (60–120 mins), and chosen path (Guidance Only vs. Pandit Ji + Samagri coordination). Every cost factor is itemized upfront before confirmation, with no hidden travel fees or uncomfortable post-puja demands."
    },
    {
      q: "Can we request a Pandit Ji who explains the vidhi in Hindi and English for children?",
      a: "Yes. In your booking request, you can specify your language preference. Our Vedic Pandits are articulate and comfortable explaining the spiritual meanings, symbolism, and mantras in Hindi, Sanskrit, or conversational English, making the ceremony deeply engaging for younger family members."
    },
    {
      q: "Is Havan included in Tulsi Vivah Puja, and is it safe for high-rise apartments in NCR?",
      a: "A traditional Tulsi Vivah centers on wedding rituals, katha, and aarti. An auspicious havan is optional and can be added upon request. For modern high-rise apartments in Noida, Delhi, and Gurugram, our Pandits use compact copper havan kunds with pure cow ghee and camphor to generate minimal smoke that will not trigger apartment smoke detectors."
    },
    {
      q: "Can unmarried daughters, couples, or elders perform the Tulsi Kanyadaan ritual?",
      a: "Yes. Performing the Kanyadaan of Devi Tulsi to Lord Shaligram is considered one of the highest spiritual virtues (Mahapunya). Married couples often perform it together, but unmarried daughters, single parents, or family elders can also actively perform the kanyadaan and sankalp with Pandit Ji's guidance."
    },
    {
      q: "How does the Online Video Tulsi Vivah Puja work for NRI or remote families?",
      a: "For devotees outside Delhi NCR or living abroad (US, UK, Canada, Australia, UAE), we conduct two-way interactive HD video ceremonies via Google Meet or Zoom. We coordinate time zones, share an easy local shopping checklist beforehand, and Pandit Ji guides your family step-by-step from our consecrated Vedic altar."
    },
    {
      q: "How early should we book for peak Devuthani Ekadashi and Kartik Purnima dates?",
      a: "Because the Kartik month window has very high demand for experienced Vedic Pandits across Delhi NCR, we strongly recommend submitting your request 5 to 10 days in advance. This ensures your preferred morning or evening muhurat slot is reserved comfortably."
    },
    {
      q: "What is Shastriya Vidhan's rescheduling and cancellation policy?",
      a: "We understand that family situations can arise. You can request to reschedule your date or timing slot by informing our booking desk at least 24 hours prior to the scheduled ceremony, subject to Pandit Ji availability within the Kartik festival window, with zero hassle."
    }
  ];

  const toggleFAQ = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section className="py-16 sm:py-20 bg-stone-50/60 border-b border-orange-100/60" id="faqs">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-orange-800 bg-orange-100 px-3.5 py-1.5 rounded-full border border-orange-200">
            Got Questions? We Have Answers
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-4 mb-4 tracking-tight">
            Frequently Asked Questions About Booking Pandit Ji for Tulsi Vivah Puja
          </h2>
          <p className="text-stone-600 text-base leading-relaxed">
            Everything you need to know about the ceremony, samagri preparation, booking timelines, and our Request-First policy.
          </p>
        </div>

        {/* 12 Accordion Items */}
        <div className="space-y-3.5">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white rounded-xl border border-orange-200/80 shadow-sm overflow-hidden transition-all"
              >
                <button
                  type="button"
                  onClick={() => toggleFAQ(idx)}
                  className="w-full text-left py-4 px-5 sm:px-6 flex items-center justify-between gap-4 font-heading text-base sm:text-lg font-bold text-stone-900 hover:text-orange-700 transition-colors min-h-[48px]"
                  aria-expanded={isOpen}
                >
                  <span className="flex items-center gap-3">
                    <span className="text-orange-600 font-normal text-sm sm:text-base">Q{idx + 1}.</span>
                    <span>{faq.q}</span>
                  </span>
                  <span className={`text-orange-600 transform transition-transform shrink-0 text-xl font-bold ${isOpen ? 'rotate-180' : ''}`}>
                    ▾
                  </span>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-5 pt-1 text-sm text-stone-600 leading-relaxed border-t border-orange-100/60 bg-amber-50/20">
                    <p>{faq.a}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still Have Questions Box */}
        <div className="mt-10 p-6 rounded-2xl bg-white border border-orange-200 text-center shadow-sm">
          <h3 className="font-heading font-bold text-stone-900 text-base mb-1">
            Have a specific gotra, muhurat, or society query?
          </h3>
          <p className="text-xs sm:text-sm text-stone-600 mb-4">
            Our Pandit coordination desk is available 7:00 AM – 9:30 PM to assist you.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <a
              href="tel:+917599340430"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-orange-50 hover:bg-orange-100 border border-orange-300 text-orange-900 font-semibold text-xs sm:text-sm min-h-[48px]"
            >
              <span>📞</span> Call +91 75993 40430
            </a>
            <a
              href="https://wa.me/917599340430?text=Namaste%20Shastriya%20Vidhan%2C%20I%20have%20a%20question%20regarding%20Tulsi%20Vivah%20Puja%20booking."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm shadow-sm min-h-[48px]"
            >
              <span>💬</span> WhatsApp Query Desk
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
export default FAQSection;
