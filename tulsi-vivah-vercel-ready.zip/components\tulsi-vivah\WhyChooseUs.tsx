import React from 'react';
import ComparisonTable from './ComparisonTable';

export const WhyChooseUs: React.FC = () => {
  const differentiators = [
    {
      title: "Acharya-Screened Pandits",
      desc: "Every priest undergoes ritual vetting under Acharya Sursain Brijwasi's standards.",
      icon: "🎖️",
    },
    {
      title: "Request-First Booking",
      desc: "Never pay upfront. We verify Pandit schedule & travel before quoting.",
      icon: "🛡️",
    },
    {
      title: "Upfront Samagri Clarity",
      desc: "Household vs. arranged items clearly demarcated in writing.",
      icon: "📋",
    },
    {
      title: "Trilingual Guidance",
      desc: "Clear explanations in Hindi, Sanskrit, and English for younger family members.",
      icon: "🗣️",
    },
    {
      title: "Punctual Delhi NCR Visits",
      desc: "Committed arrival windows across Noida, Delhi, Gurugram & Ghaziabad.",
      icon: "⏰",
    },
    {
      title: "Global Online Video Mode",
      desc: "Interactive HD two-way sessions for NRI families in US, UK, Canada & UAE.",
      icon: "💻",
    },
    {
      title: "100% Itemized Pricing",
      desc: "Transparent quote based on travel, duration, and samagri—no hidden surcharges.",
      icon: "🧾",
    },
    {
      title: "Strictly Ethical Sanatan Vidhi",
      desc: "Zero fear claims, zero miracle promises—pure Vedic devotion and family prayer.",
      icon: "🕊️",
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-gradient-to-b from-stone-50/50 via-white to-amber-50/30 border-b border-orange-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-orange-800 bg-orange-100 px-3.5 py-1.5 rounded-full border border-orange-200">
            The Shastriya Vidhan Advantage
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-4 mb-4 tracking-tight">
            Why Families in Delhi NCR &amp; Worldwide Trust Shastriya Vidhan
          </h2>
          <p className="text-stone-600 text-base leading-relaxed">
            We blend the timeless sanctity of Vedic traditions with modern transparency, punctuality, and complete peace of mind.
          </p>
        </div>

        {/* 8 Concise Differentiator Badges */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-16">
          {differentiators.map((diff, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl p-5 border border-orange-100 shadow-sm hover:shadow-md transition-all flex flex-col justify-start"
            >
              <div className="text-2xl mb-2.5">{diff.icon}</div>
              <h3 className="font-heading font-bold text-stone-900 text-base mb-1.5">
                {diff.title}
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                {diff.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Responsive Comparison Table Sub-component */}
        <div className="mt-8">
          <div className="text-center mb-6">
            <h3 className="font-heading text-xl sm:text-2xl font-bold text-stone-900">
              How We Compare Against Other Options
            </h3>
            <p className="text-sm text-stone-600 mt-1">
              See why our Request-First model protects families from festive stress
            </p>
          </div>
          <ComparisonTable />
        </div>

      </div>
    </section>
  );
};
export default WhyChooseUs;
