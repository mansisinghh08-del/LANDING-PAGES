import React from 'react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      num: "01",
      title: "Submit Your Priority Request",
      desc: "Fill our simple 4-step request form selecting Tulsi Vivah Puja, your preferred mode (Home Visit in NCR or Online Video), and preferred date between Devuthani Ekadashi and Kartik Purnima.",
      icon: "📝",
    },
    {
      num: "02",
      title: "Manual Availability & Scope Review",
      desc: "Our booking desk reviews your request, verifies Pandit Ji availability for your exact locality (Noida, Delhi, Gurugram, Ghaziabad), and matches language and family traditions.",
      icon: "🔍",
    },
    {
      num: "03",
      title: "Receive Samagri Checklist & Quote",
      desc: "You receive an itemized, clear quote along with the household samagri checklist. You pay nothing until you have reviewed and fully approved the arrangement.",
      icon: "📋",
    },
    {
      num: "04",
      title: "Perform Your Puja Peacefully",
      desc: "Your assigned Vedic Pandit arrives punctually with required ritual items (or connects via high-definition video) to guide your family through a serene and authentic ceremony.",
      icon: "🙏",
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-white border-b border-orange-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-amber-800 bg-amber-100/80 px-3.5 py-1.5 rounded-full border border-amber-300">
            Transparent Booking Flow
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-4 mb-4 tracking-tight">
            How to Book Pandit Ji for Tulsi Vivah in 4 Simple Steps
          </h2>
          <p className="text-stone-600 text-base leading-relaxed">
            From initial enquiry to the final aarti, every step is coordinated with care, reverence, and complete transparency.
          </p>
        </div>

        {/* 4 Step Cards with Connecting Line on Desktop */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {steps.map((step, idx) => (
            <div
              key={idx}
              className="bg-stone-50/70 rounded-2xl p-6 border border-orange-200/80 hover:border-orange-300 hover:bg-white shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="w-10 h-10 rounded-full bg-gradient-to-r from-orange-600 to-amber-700 text-white font-heading font-bold text-sm flex items-center justify-center shadow-sm">
                    {step.num}
                  </span>
                  <span className="text-2xl group-hover:scale-110 transition-transform">
                    {step.icon}
                  </span>
                </div>

                <h3 className="font-heading text-lg font-bold text-stone-900 mb-2">
                  {step.title}
                </h3>
                <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                  {step.desc}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-stone-200/70 text-[11px] font-semibold text-orange-700 uppercase tracking-wide">
                Phase {step.num} • Zero Stress
              </div>
            </div>
          ))}
        </div>

        {/* CTA Button */}
        <div className="mt-12 text-center">
          <a
            href="#book-pandit-ji"
            className="inline-flex items-center justify-center px-8 py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-700 hover:from-orange-700 hover:to-amber-800 text-white font-bold text-base shadow-lg hover:shadow-xl transition-all"
          >
            <span>Start Step 1: Submit Your Priority Request</span>
            <span className="ml-2 font-bold">→</span>
          </a>
        </div>

      </div>
    </section>
  );
};
export default HowItWorks;
