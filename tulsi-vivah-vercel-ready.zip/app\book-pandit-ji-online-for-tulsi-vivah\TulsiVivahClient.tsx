'use client';

import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HeroSection from '@/components/tulsi-vivah/HeroSection';
import ProblemSection from '@/components/tulsi-vivah/ProblemSection';
import SolutionSection from '@/components/tulsi-vivah/SolutionSection';
import BenefitsSection from '@/components/tulsi-vivah/BenefitsSection';
import CeremonialInclusions from '@/components/tulsi-vivah/CeremonialInclusions';
import WhyChooseUs from '@/components/tulsi-vivah/WhyChooseUs';
import HowItWorks from '@/components/tulsi-vivah/HowItWorks';
import PricingFactors from '@/components/tulsi-vivah/PricingFactors';
import DevoteeReviews from '@/components/tulsi-vivah/DevoteeReviews';
import FAQSection from '@/components/tulsi-vivah/FAQSection';
import PriorityRequestForm from '@/components/tulsi-vivah/PriorityRequestForm';
import FestivalUrgencyCTA from '@/components/tulsi-vivah/FestivalUrgencyCTA';
import StickyMobileBar from '@/components/tulsi-vivah/StickyMobileBar';
import PreparationGuidesStrip from '@/components/tulsi-vivah/PreparationGuidesStrip';

export const TulsiVivahClient: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-[#FFFDF9] text-stone-900 selection:bg-orange-200 selection:text-orange-900">
      {/* Global Navigation Header */}
      <Header />

      <main className="flex-grow">
        {/* Section 1: Hero */}
        <HeroSection />

        {/* Section 2: Problem Section (PAS Framework) */}
        <ProblemSection />

        {/* Section 3: The Solution ("The Shastriya Vidhan Standard") */}
        <SolutionSection />

        {/* Section 4: Outcome-Focused Benefits */}
        <BenefitsSection />

        {/* Section 5: Ceremonial Inclusions & Ritual Scope */}
        <CeremonialInclusions />

        {/* Section 6: Why Choose Us & Comparison Table */}
        <WhyChooseUs />

        {/* Section 7: How It Works (4-Step Journey) */}
        <HowItWorks />

        {/* Section 8: Transparent Pricing Factors & Path A/B */}
        <PricingFactors />

        {/* Section 9: Devotee Reviews & Social Proof */}
        <DevoteeReviews />

        {/* Section 10: Objection-Handling 12 FAQs */}
        <FAQSection />

        {/* Section 11: Multi-Step Priority Request Form */}
        <PriorityRequestForm />

        {/* Section 12: Final Festival Urgency CTA */}
        <FestivalUrgencyCTA />

        {/* Preparation Guides Hub-and-Spoke Strip */}
        <PreparationGuidesStrip />
      </main>

      {/* Global Footer */}
      <Footer />

      {/* Mobile Sticky Conversion Bar */}
      <StickyMobileBar />
    </div>
  );
};
export default TulsiVivahClient;
