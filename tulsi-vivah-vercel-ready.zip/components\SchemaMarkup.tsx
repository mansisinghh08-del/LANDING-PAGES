import React from 'react';

export const SchemaMarkup: React.FC = () => {
  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": "Tulsi Vivah Puja Pandit Ji Booking",
    "serviceType": "Vedic Puja and Pandit Booking Service",
    "provider": {
      "@type": "Organization",
      "name": "Shastriya Vidhan",
      "url": "https://www.shastriyavidhan.com",
      "logo": "https://www.shastriyavidhan.com/images/shastriya-vidhan-logo.png",
      "telephone": "+917599340430",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+917599340430",
        "contactType": "customer service",
        "availableLanguage": ["Hindi", "English", "Sanskrit"],
        "areaServed": ["IN", "Worldwide"]
      }
    },
    "areaServed": [
      { "@type": "City", "name": "Noida" },
      { "@type": "City", "name": "Delhi" },
      { "@type": "City", "name": "Gurugram" },
      { "@type": "City", "name": "Ghaziabad" },
      { "@type": "AdministrativeArea", "name": "Worldwide (Online)" }
    ],
    "description": "Book a verified Vedic Pandit Ji for authentic Tulsi Vivah Puja at home in Noida, Delhi, Gurugram or via interactive online video. Complete samagri coordination, traditional Shaligram-Tulsi vivah vidhi, katha, and transparent quotes before payment.",
    "offers": {
      "@type": "Offer",
      "availability": "https://schema.org/InStock",
      "priceCurrency": "INR",
      "description": "Transparent personalized quote provided upon manual availability check. No payment required before quote clarity."
    }
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://www.shastriyavidhan.com/"
      },
      {
        "@type": "ListItem",
        "position": 2,
        "name": "Puja Services",
        "item": "https://www.shastriyavidhan.com/puja-services"
      },
      {
        "@type": "ListItem",
        "position": 3,
        "name": "Festival Pujas",
        "item": "https://www.shastriyavidhan.com/puja-services/festival-pujas"
      },
      {
        "@type": "ListItem",
        "position": 4,
        "name": "Book Pandit Ji Online for Tulsi Vivah",
        "item": "https://www.shastriyavidhan.com/book-pandit-ji-online-for-tulsi-vivah"
      }
    ]
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "When is Tulsi Vivah Puja performed in Kartik month (Devuthani Ekadashi to Kartik Purnima)?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "Tulsi Vivah is traditionally observed during Shukla Paksha of the sacred Kartik month, commencing on Devuthani Ekadashi (Prabodhini Ekadashi, when Lord Vishnu awakens from Yoga Nidra) and extending through Dwadashi up to Kartik Purnima. Families can choose an auspicious muhurat within this window based on their family tradition and Pandit Ji availability."
        }
      },
      {
        "@type": "Question",
        "name": "How do I book a Pandit Ji for Tulsi Vivah Puja at home in Noida, Delhi, or Gurugram?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "Simply submit our 4-step Priority Request Form with your preferred date, city/sector, and puja mode. Our booking coordinator verifies Acharya-screened Pandit Ji availability, confirms travel feasibility, shares an upfront samagri checklist, and gives you a complete quote. Once you review and approve the quote, your booking is confirmed."
        }
      },
      {
        "@type": "Question",
        "name": "Do I have to pay immediately when submitting the request form?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "No. Under 'The Shastriya Vidhan Standard,' we follow a strict Request-First policy. You pay nothing when submitting your request. We first manually verify Pandit availability, travel feasibility, and exact samagri scope, providing 100% quote clarity before any payment or advance is accepted."
        }
      },
      {
        "@type": "Question",
        "name": "What is the typical duration of the Tulsi Vivah ceremony?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "A standard Shastrokt Tulsi Vivah ceremony typically takes between 60 to 120 minutes. This includes Swasti Vachan, Sankalp, Ganesh-Gauri puja, Kalash sthapana, Shaligram abhishek, the complete wedding rituals (gathbandhan, kanyadaan, mangalashtak), Tulsi katha recitation, and concluding family aarti."
        }
      },
      {
        "@type": "Question",
        "name": "Who arranges the Tulsi Vivah Puja Samagri, Shaligram Ji, and Ganne ka Mandap?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "We offer two flexible options: In Path A, the family arranges the items using our itemized checklist (sugarcane stalks, red chunri, fruits, flowers, daily puja items). In Path B, our Pandit Ji coordinates and brings the specialized ritual samagri kit. Families typically provide the live Tulsi plant; if your home does not have a Shaligram Shila, Pandit Ji can bring a sanctified Shaligram Ji for the ceremony."
        }
      },
      {
        "@type": "Question",
        "name": "How much does it cost to book a Pandit Ji for Tulsi Vivah?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "The dakshina and service quote depend on your chosen booking path (Pandit guidance only vs. complete samagri coordination), puja mode (home visit in Noida/Delhi/Gurugram vs. online video), ceremony duration, and optional add-ons like havan. All cost factors are itemized transparently in your quote before confirmation with zero hidden charges."
        }
      },
      {
        "@type": "Question",
        "name": "Can we request a Pandit Ji who explains the vidhi in Hindi and English for children?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "Yes, absolutely. Our Vedic Pandits are deeply knowledgeable and articulate. You can specify language preferences (Hindi, Sanskrit, English, or regional traditions) in your booking request so younger family members understand the spiritual significance of each mantra and ritual step."
        }
      },
      {
        "@type": "Question",
        "name": "Is Havan included in Tulsi Vivah Puja, and is it safe for high-rise apartments in NCR?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "A traditional Tulsi Vivah focuses on the ceremonial wedding rituals, kanyadaan, and katha. A small auspicious havan can be included upon request. For modern apartments in Noida, Delhi, and Gurugram, our Pandits use compact copper havan kunds with minimal pure cow ghee and camphor to ensure low smoke that is completely safe for indoor smoke detectors."
        }
      },
      {
        "@type": "Question",
        "name": "Can unmarried daughters, couples, or elders perform the Tulsi Kanyadaan ritual?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "Yes. Performing the Kanyadaan of Tulsi Mata to Lord Shaligram is considered one of the highest spiritual virtues (Punya) in Vedic scriptures. Married couples often perform it together as kanyadaan, but elders, single parents, or whole families can participate collectively in the sankalp and offerings."
        }
      },
      {
        "@type": "Question",
        "name": "How does the Online Video Tulsi Vivah Puja work for NRI or remote families?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "For families outside Delhi NCR or living abroad (US, UK, Canada, Australia, UAE), we conduct interactive, two-way HD video sessions (Google Meet / Zoom). We send you an easy-to-source checklist beforehand. Pandit Ji chants live from our Vedic sanctum, chanting family gotras and guiding you step-by-step in your own home."
        }
      },
      {
        "@type": "Question",
        "name": "How early should we book for peak Devuthani Ekadashi and Kartik Purnima dates?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "Because the Kartik festival window is limited and demand for experienced Vedic Pandits in Delhi NCR is exceptionally high, we strongly advise submitting your priority request 5 to 10 days in advance to secure your preferred morning or evening muhurat slot."
        }
      },
      {
        "@type": "Question",
        "name": "What is Shastriya Vidhan's rescheduling and cancellation policy?",
        "acceptedAnswer": {
          "@type": "AcceptedAnswer",
          "text": "We understand that family schedules can change. You can request a date or time slot shift by contacting our booking desk at least 24 hours prior to the scheduled puja, subject to Pandit Ji availability within the Kartik month window, with complete peace of mind."
        }
      }
    ]
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
    </>
  );
};
export default SchemaMarkup;
