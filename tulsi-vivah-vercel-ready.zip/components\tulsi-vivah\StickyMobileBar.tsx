import React from 'react';

export const StickyMobileBar: React.FC = () => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-white/95 backdrop-blur-md border-t border-orange-200 px-3 py-2 shadow-2xl">
      <div className="flex items-center gap-2 max-w-md mx-auto">
        {/* Left: Call Desk CTA */}
        <a
          href="tel:+917599340430"
          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-3 rounded-xl border border-orange-300 bg-orange-50 text-stone-900 font-bold text-xs shadow-sm min-h-[48px] active:bg-orange-100"
        >
          <svg className="w-4 h-4 text-orange-600 shrink-0" fill="currentColor" viewBox="0 0 24 24">
            <path d="M6.62 10.79a15.053 15.053 0 006.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" />
          </svg>
          <span>Call Desk</span>
        </a>

        {/* Right: Primary Request CTA (Scrolls to Wizard) */}
        <a
          href="#book-pandit-ji"
          className="flex-[1.4] flex items-center justify-center gap-1.5 px-3 py-3 rounded-xl bg-gradient-to-r from-orange-600 to-amber-700 text-white font-bold text-xs shadow-md min-h-[48px] active:opacity-90"
        >
          <span>Request Quote</span>
          <span className="text-amber-200">✨</span>
        </a>

        {/* Quick WhatsApp Floating Pill */}
        <a
          href="https://wa.me/917599340430?text=Namaste%20Shastriya%20Vidhan%2C%20I%20want%20to%20book%20a%20Pandit%20Ji%20for%20Tulsi%20Vivah%20Puja.%20Please%20share%20availability%20and%20quote."
          target="_blank"
          rel="noopener noreferrer"
          className="w-12 h-12 rounded-xl bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-md active:bg-emerald-700 min-h-[48px] min-w-[48px]"
          aria-label="WhatsApp Booking Desk"
        >
          <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981z" />
          </svg>
        </a>
      </div>
    </div>
  );
};
export default StickyMobileBar;
