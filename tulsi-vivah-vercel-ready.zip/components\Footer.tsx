import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-900 text-stone-300 pt-16 pb-24 md:pb-16 border-t border-amber-900/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="relative w-48 h-12 bg-white/95 rounded-lg p-1.5 inline-block">
              <Image
                src="/images/shastriya-vidhan-logo.png"
                alt="Shastriya Vidhan"
                fill
                className="object-contain"
              />
            </div>
            <p className="text-sm leading-relaxed text-stone-400">
              Shastriya Vidhan connects devout families with experienced, Gurukul-trained Vedic Pandits for authentic home sanctum rituals and online ceremonies, guided by the sacred principles of Acharya Sursain Brijwasi.
            </p>
            <div className="pt-2 text-xs text-amber-400 font-medium">
              Vedic Vidhi • Shastrokt Chanting • Request-First Clarity
            </div>
          </div>

          {/* Quick Contact & Booking Desk */}
          <div>
            <h4 className="font-heading text-lg font-semibold text-amber-400 mb-4 tracking-wide">
              Pandit Ji Booking Desk
            </h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2.5">
                <span className="text-orange-500 mt-0.5">📞</span>
                <div>
                  <div className="text-stone-400 text-xs">Direct Support &amp; Queries</div>
                  <a href="tel:+917599340430" className="hover:text-amber-400 font-semibold text-stone-200">
                    +91 75993 40430
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-green-500 mt-0.5">💬</span>
                <div>
                  <div className="text-stone-400 text-xs">Instant WhatsApp Desk</div>
                  <a
                    href="https://wa.me/917599340430?text=Namaste%20Shastriya%20Vidhan%2C%20I%20want%20to%20book%20a%20Pandit%20Ji%20for%20Tulsi%20Vivah%20Puja.%20Please%20share%20availability%20and%20quote."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-amber-400 font-semibold text-stone-200"
                  >
                    Chat with Booking Coordinator
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-amber-500 mt-0.5">⏰</span>
                <div>
                  <div className="text-stone-400 text-xs">Desk Working Hours</div>
                  <div className="text-stone-300">7:00 AM – 9:30 PM (All 7 Days)</div>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="text-amber-500 mt-0.5">📍</span>
                <div>
                  <div className="text-stone-400 text-xs">Physical Coverage</div>
                  <div className="text-stone-300">Noida, Greater Noida, Delhi, Gurugram, Ghaziabad</div>
                </div>
              </li>
            </ul>
          </div>

          {/* Preparation & Ritual Guides (Hub-and-Spoke Links) */}
          <div>
            <h4 className="font-heading text-lg font-semibold text-amber-400 mb-4 tracking-wide">
              Helpful Preparation Guides
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link
                  href="/guides#festival-guides"
                  className="hover:text-amber-400 text-stone-300 transition-colors inline-flex items-center gap-1.5"
                >
                  <span className="text-amber-600">›</span>
                  <span>Kartik Month &amp; Devuthani Ekadashi Muhurat Windows</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/guides#samagri-guidance"
                  className="hover:text-amber-400 text-stone-300 transition-colors inline-flex items-center gap-1.5"
                >
                  <span className="text-amber-600">›</span>
                  <span>Standard Tulsi Vivah Samagri Checklist</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/guides#puja-preparation"
                  className="hover:text-amber-400 text-stone-300 transition-colors inline-flex items-center gap-1.5"
                >
                  <span className="text-amber-600">›</span>
                  <span>How to Prepare Your Home Sanctum for Puja</span>
                </Link>
              </li>
              <li>
                <Link
                  href="/locations/noida"
                  className="hover:text-amber-400 text-stone-300 transition-colors inline-flex items-center gap-1.5"
                >
                  <span className="text-amber-600">›</span>
                  <span>Pandit Ji Availability in Noida, Delhi &amp; Gurugram</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Service Areas & Verified Coverage */}
          <div>
            <h4 className="font-heading text-lg font-semibold text-amber-400 mb-4 tracking-wide">
              Coverage &amp; Ritual Formats
            </h4>
            <p className="text-xs text-stone-400 mb-3 leading-relaxed">
              We arrange verified Vedic Pandit Ji home visits across Delhi NCR and interactive HD online ceremonies globally.
            </p>
            <div className="flex flex-wrap gap-1.5 text-xs">
              <span className="px-2 py-1 rounded bg-stone-800 text-stone-300 border border-stone-700">Noida (All Sectors)</span>
              <span className="px-2 py-1 rounded bg-stone-800 text-stone-300 border border-stone-700">South &amp; East Delhi</span>
              <span className="px-2 py-1 rounded bg-stone-800 text-stone-300 border border-stone-700">Gurugram (DLF &amp; Golf Course)</span>
              <span className="px-2 py-1 rounded bg-stone-800 text-stone-300 border border-stone-700">Ghaziabad &amp; Indirapuram</span>
              <span className="px-2 py-1 rounded bg-amber-950/60 text-amber-300 border border-amber-800">Online NRI Video Vidhi</span>
            </div>
          </div>
        </div>

        {/* Ethical Standard & Disclaimer Box */}
        <div className="bg-stone-800/80 rounded-xl p-5 border border-stone-700/60 mb-8 text-xs leading-relaxed text-stone-400">
          <div className="flex items-center gap-2 text-amber-400 font-semibold mb-1.5 text-sm">
            <span>🛡️</span>
            <span>The Shastriya Vidhan Ethical Devotional Standard:</span>
          </div>
          <p>
            Tulsi Vivah Puja is a sacred Vedic ritual celebrating the divine union of Tulsi Mata and Lord Shaligram, symbolizing purity, auspiciousness, and spiritual harmony. Shastriya Vidhan adheres strictly to authentic Shastrokt Vidhi. We do not make supernatural, fear-based, or guaranteed marital/material outcome claims. Every puja is an offering of pure devotion (bhakti) and family prayer. All booking requests are reviewed manually for Pandit schedule and samagri feasibility, and quotes are finalized with full transparency before any payment is collected.
          </p>
        </div>

        {/* Copyright and Legal Notice */}
        <div className="pt-6 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-4">
          <p>© {new Date().getFullYear()} Shastriya Vidhan. All Rights Reserved. Dedicated to authentic Vedic heritage.</p>
          <div className="flex items-center gap-6">
            <Link href="/" className="hover:text-amber-400">Home</Link>
            <Link href="/book-pandit-ji-online-for-tulsi-vivah" className="hover:text-amber-400">Tulsi Vivah Puja</Link>
            <a href="tel:+917599340430" className="hover:text-amber-400">+91 75993 40430</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
export default Footer;
