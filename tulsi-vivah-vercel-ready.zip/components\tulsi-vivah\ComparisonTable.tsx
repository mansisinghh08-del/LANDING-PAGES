import React from 'react';

export const ComparisonTable: React.FC = () => {
  const comparisonData = [
    {
      feature: "Pandit Screening & Standards",
      shastriya: "Strictly vetted under Acharya Sursain Brijwasi; Gurukul trained in authentic Vedic rituals & proper pronunciation.",
      generic: "Aggregated freelance listings with little to no religious vetting or ritual quality audits.",
      local: "Varies widely; heavily dependent on word of mouth with no quality standard or verification.",
    },
    {
      feature: "Payment Timing & Financial Risk",
      shastriya: "Request-First Policy: 100% free review. Quote & scope confirmed before any payment or commitment.",
      generic: "Forced 100% upfront payment on checkout before verifying Pandit travel or slot feasibility.",
      local: "Informal promises; post-puja unexpected fee demands, travel additions, or dakshina disputes.",
    },
    {
      feature: "Samagri Clarity & Checklist",
      shastriya: "Structured itemized list shared upfront, clearly separating household items from arranged kit items.",
      generic: "Vague 'Standard Kit' with unspecified quantities; missing key festive items on puja day.",
      local: "Handwritten or verbal list shared last minute, leading to frantic market runs before muhurat.",
    },
    {
      feature: "Language & Tradition Matching",
      shastriya: "Customized to family preferences: Hindi, Sanskrit, and English explanations for children and youth.",
      generic: "Random Pandit assigned based solely on zip code availability, often ignoring language comfort.",
      local: "Limited to local dialect; often unable to explain ritual meanings to English-speaking family members.",
    },
    {
      feature: "Ethical Communication & Tone",
      shastriya: "Strict Sanatan ethics: purely devotional family prayer. Zero fear tactics, zero miracle promises.",
      generic: "Commercialized upsells, pushing unnecessary extra rituals or astrological fear remediation.",
      local: "Unpredictable; occasionally introduces superstition, dosha claims, or pressure for higher dakshina.",
    },
  ];

  return (
    <div className="bg-white rounded-2xl border border-orange-200 shadow-md overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[650px]">
          <thead>
            <tr className="border-b border-orange-200">
              <th className="py-4 px-5 text-sm font-bold text-stone-700 bg-stone-50 w-1/4">
                Comparison Factor
              </th>
              <th className="py-4 px-5 text-sm font-bold text-orange-800 bg-orange-100/90 w-1/3 border-x-2 border-orange-400">
                <div className="flex items-center gap-1.5">
                  <span className="text-orange-600">★</span>
                  <span>Shastriya Vidhan (Request-First)</span>
                </div>
              </th>
              <th className="py-4 px-5 text-sm font-semibold text-stone-600 bg-stone-50 w-1/5">
                Generic Instant-Pay Portals
              </th>
              <th className="py-4 px-5 text-sm font-semibold text-stone-600 bg-stone-50 w-1/5">
                Unorganized Local Search
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-orange-100/70 text-xs sm:text-sm">
            {comparisonData.map((row, idx) => (
              <tr key={idx} className="hover:bg-amber-50/20 transition-colors">
                <td className="py-4 px-5 font-bold text-stone-900 bg-stone-50/50 align-top">
                  {row.feature}
                </td>
                <td className="py-4 px-5 font-medium text-stone-800 bg-orange-50/40 border-x-2 border-orange-300/80 align-top leading-relaxed">
                  <div className="flex items-start gap-1.5">
                    <span className="text-emerald-600 font-bold text-base leading-none">✓</span>
                    <span>{row.shastriya}</span>
                  </div>
                </td>
                <td className="py-4 px-5 text-stone-600 align-top leading-relaxed">
                  <div className="flex items-start gap-1.5">
                    <span className="text-rose-500 font-bold text-base leading-none">✕</span>
                    <span>{row.generic}</span>
                  </div>
                </td>
                <td className="py-4 px-5 text-stone-600 align-top leading-relaxed">
                  <div className="flex items-start gap-1.5">
                    <span className="text-amber-600 font-bold text-base leading-none">△</span>
                    <span>{row.local}</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Table Footer Summary Note */}
      <div className="p-4 bg-orange-50/50 border-t border-orange-200 text-center text-xs text-stone-600">
        <span className="font-semibold text-orange-900">Summary:</span> Shastriya Vidhan gives families full transparency, vetted priests, and zero financial risk before confirming your Tulsi Vivah Puja.
      </div>
    </div>
  );
};
export default ComparisonTable;
