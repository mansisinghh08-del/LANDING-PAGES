import React, { useState } from 'react';

export const PriorityRequestForm: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  // Form State
  const [formData, setFormData] = useState({
    service: "Tulsi Vivah Puja",
    mode: "Home Visit (Delhi NCR)",
    samagriPath: "Path B: Pandit Ji + Samagri Support",
    havanAddon: false,
    extendedKatha: false,
    dateType: "Devuthani Ekadashi",
    customDate: "",
    timeWindow: "Evening Godhuli / Twilight (4:30 PM – 7:30 PM)",
    city: "Noida",
    locality: "",
    name: "",
    phone: "",
    email: "",
    gotra: "",
    language: "Hindi & Sanskrit with English explanation",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleNext = () => {
    if (currentStep === 1) {
      setCurrentStep(2);
    } else if (currentStep === 2) {
      if (!formData.city) {
        alert("Please select your city or online mode.");
        return;
      }
      setCurrentStep(3);
    } else if (currentStep === 3) {
      if (!formData.name.trim()) {
        alert("Please enter your name.");
        return;
      }
      if (!formData.phone.trim() || formData.phone.length < 10) {
        alert("Please enter a valid 10-digit WhatsApp phone number.");
        return;
      }
      setCurrentStep(4);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);

    // Format WhatsApp message
    const msg = `Namaste Shastriya Vidhan! I have submitted a Priority Request for Tulsi Vivah Puja:
- Name: ${formData.name}
- Phone: ${formData.phone}
- Service: ${formData.service}
- Mode: ${formData.mode}
- City/Locality: ${formData.city} ${formData.locality ? `(${formData.locality})` : ''}
- Date Preference: ${formData.dateType === 'Custom Date' ? formData.customDate : formData.dateType}
- Time Window: ${formData.timeWindow}
- Samagri: ${formData.samagriPath}
- Havan Addon: ${formData.havanAddon ? 'Yes' : 'No'}
- Language: ${formData.language}
Please verify Pandit Ji availability and share the exact quote.`;

    const encodedMsg = encodeURIComponent(msg);
    const waUrl = `https://wa.me/917599340430?text=${encodedMsg}`;

    // Gracefully open WhatsApp in new tab
    if (typeof window !== 'undefined') {
      window.open(waUrl, '_blank');
    }
  };

  return (
    <section id="book-pandit-ji" className="py-16 sm:py-24 bg-gradient-to-b from-stone-50 via-amber-50/30 to-stone-100 border-b border-orange-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 text-emerald-900 text-xs sm:text-sm font-bold border border-emerald-300 mb-3">
            <span>🛡️</span> Zero Financial Risk • No Payment Before Quote Clarity
          </div>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 tracking-tight">
            Tulsi Vivah Puja Priority Request Form
          </h2>
          <p className="text-stone-600 text-sm sm:text-base mt-2 max-w-2xl mx-auto">
            Reserve your preferred Kartik month muhurat window in 4 simple steps. We will manually check Pandit Ji availability and share an itemized quote.
          </p>
        </div>

        {/* Wizard Container */}
        <div className="bg-white rounded-3xl border-2 border-orange-200 shadow-vedic-lg p-6 sm:p-10 relative overflow-hidden">
          
          {/* Step Progress Bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-stone-600 mb-2">
              <span className={currentStep >= 1 ? "text-orange-700" : ""}>1. Service Scope</span>
              <span className={currentStep >= 2 ? "text-orange-700" : ""}>2. Schedule &amp; City</span>
              <span className={currentStep >= 3 ? "text-orange-700" : ""}>3. Devotee Details</span>
              <span className={currentStep >= 4 ? "text-orange-700" : ""}>4. Free Review</span>
            </div>
            <div className="w-full bg-stone-100 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-orange-600 to-amber-600 h-full transition-all duration-300 ease-out"
                style={{ width: `${(currentStep / 4) * 100}%` }}
              />
            </div>
          </div>

          {isSubmitted ? (
            /* Success State */
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center text-3xl mx-auto">
                ✓
              </div>
              <h3 className="font-heading text-2xl font-bold text-stone-900">
                Priority Request Received!
              </h3>
              <p className="text-stone-600 text-sm max-w-lg mx-auto">
                Thank you, <strong>{formData.name}</strong>. Our booking desk is currently verifying Pandit Ji availability for <strong>{formData.city}</strong> for your selected Kartik slot.
              </p>
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 max-w-md mx-auto text-xs text-stone-700 text-left space-y-1.5">
                <div><strong>What happens next?</strong></div>
                <div>1. Our coordinator checks travel &amp; muhurat schedule (typically 30–60 mins).</div>
                <div>2. You receive an itemized quote &amp; samagri checklist on WhatsApp ({formData.phone}).</div>
                <div>3. You confirm only if 100% satisfied. No payment is charged right now.</div>
              </div>
              <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
                <a
                  href={`https://wa.me/917599340430?text=Namaste%20Shastriya%20Vidhan%2C%20I%20just%20submitted%20a%20request%20for%20Tulsi%20Vivah%20Puja%20under%20name%20${encodeURIComponent(formData.name)}.%20Please%20verify%20availability.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm shadow-md"
                >
                  Open WhatsApp Chat Instantly
                </a>
                <button
                  type="button"
                  onClick={() => {
                    setIsSubmitted(false);
                    setCurrentStep(1);
                  }}
                  className="px-6 py-3 rounded-xl border border-stone-300 text-stone-700 hover:bg-stone-50 text-sm font-medium"
                >
                  Submit Another Request
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* STEP 1: SERVICE */}
              {currentStep === 1 && (
                <div className="space-y-6 animate-fadeIn">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1.5">
                      Selected Puja Service
                    </label>
                    <div className="p-3.5 rounded-xl bg-orange-50 border border-orange-200 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">🌿</span>
                        <span className="font-heading font-bold text-stone-900 text-base">
                          {formData.service}
                        </span>
                      </div>
                      <span className="text-xs font-semibold px-2.5 py-1 rounded bg-orange-200/70 text-orange-950">
                        Pre-Selected
                      </span>
                    </div>
                  </div>

                  {/* Mode of Puja */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">
                      Choose Ceremony Mode
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        { title: "Home Visit (Delhi NCR)", desc: "Pandit Ji visits your home in Noida, Delhi, Gurugram or Ghaziabad", icon: "🏡" },
                        { title: "Online Video Mode", desc: "Interactive HD 2-way ceremony for NRIs & families outside NCR", icon: "💻" },
                      ].map((modeOption, idx) => (
                        <div
                          key={idx}
                          onClick={() => setFormData(prev => ({ ...prev, mode: modeOption.title }))}
                          className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex items-start gap-3 min-h-[48px] ${
                            formData.mode === modeOption.title
                              ? 'border-orange-600 bg-orange-50/50 shadow-sm'
                              : 'border-stone-200 hover:border-orange-300 bg-white'
                          }`}
                        >
                          <span className="text-xl mt-0.5">{modeOption.icon}</span>
                          <div>
                            <div className="font-bold text-sm text-stone-900">{modeOption.title}</div>
                            <div className="text-xs text-stone-500 leading-tight mt-0.5">{modeOption.desc}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Samagri Arrangement Path */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">
                      Samagri Coordination Preference
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        {
                          path: "Path B: Pandit Ji + Samagri Support",
                          title: "Path B: Coordinated Puja Kit",
                          desc: "Pandit Ji brings ritual kit, suhaag items & mandap essentials. You only prepare fresh fruits & milk.",
                          badge: "Recommended",
                        },
                        {
                          path: "Path A: Guidance Only (Family Arranges Samagri)",
                          title: "Path A: Guidance Only",
                          desc: "We share our full itemized checklist. Your family arranges all items at home.",
                          badge: "Traditional",
                        },
                      ].map((sOption, idx) => (
                        <div
                          key={idx}
                          onClick={() => setFormData(prev => ({ ...prev, samagriPath: sOption.path }))}
                          className={`p-4 rounded-xl border-2 cursor-pointer transition-all min-h-[48px] ${
                            formData.samagriPath === sOption.path
                              ? 'border-orange-600 bg-orange-50/50 shadow-sm'
                              : 'border-stone-200 hover:border-orange-300 bg-white'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-sm text-stone-900">{sOption.title}</span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-stone-100 text-stone-700">
                              {sOption.badge}
                            </span>
                          </div>
                          <p className="text-xs text-stone-500 leading-tight">{sOption.desc}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Optional Addons */}
                  <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 space-y-3">
                    <span className="block text-xs font-bold uppercase tracking-wider text-stone-600">
                      Optional Ceremonial Add-ons
                    </span>
                    <label className="flex items-center gap-3 cursor-pointer text-xs sm:text-sm text-stone-700 min-h-[44px]">
                      <input
                        type="checkbox"
                        name="havanAddon"
                        checked={formData.havanAddon}
                        onChange={handleInputChange}
                        className="w-4 h-4 text-orange-600 rounded border-stone-300 focus:ring-orange-500"
                      />
                      <span>Include low-smoke apartment-safe Havan (compact copper kund with pure cow ghee)</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer text-xs sm:text-sm text-stone-700 min-h-[44px]">
                      <input
                        type="checkbox"
                        name="extendedKatha"
                        checked={formData.extendedKatha}
                        onChange={handleInputChange}
                        className="w-4 h-4 text-orange-600 rounded border-stone-300 focus:ring-orange-500"
                      />
                      <span>Include extended Vishnu Sahasranama / Mangalashtak recitation</span>
                    </label>
                  </div>
                </div>
              )}

              {/* STEP 2: SCHEDULE & CITY */}
              {currentStep === 2 && (
                <div className="space-y-6 animate-fadeIn">
                  {/* Date Selection */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">
                      Preferred Date in Kartik Month
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-3">
                      {[
                        { title: "Devuthani Ekadashi", sub: "Most Auspicious Opening" },
                        { title: "Tulsi Vivah Dwadashi", sub: "Traditional Wedding Day" },
                        { title: "Kartik Purnima", sub: "Holy Full Moon Climax" },
                      ].map((dOption, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setFormData(prev => ({ ...prev, dateType: dOption.title }))}
                          className={`p-3 rounded-xl border text-left transition-all min-h-[48px] ${
                            formData.dateType === dOption.title
                              ? 'border-orange-600 bg-orange-50 font-bold text-orange-950 shadow-sm'
                              : 'border-stone-200 bg-white hover:border-orange-300 text-stone-700'
                          }`}
                        >
                          <div className="text-xs sm:text-sm">{dOption.title}</div>
                          <div className="text-[11px] text-stone-500">{dOption.sub}</div>
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-3">
                      <label className="flex items-center gap-2 text-xs font-semibold text-stone-600 cursor-pointer min-h-[44px]">
                        <input
                          type="radio"
                          name="dateTypeChoice"
                          checked={formData.dateType === 'Custom Date'}
                          onChange={() => setFormData(prev => ({ ...prev, dateType: 'Custom Date' }))}
                          className="text-orange-600"
                        />
                        <span>Other Date in Kartik Month:</span>
                      </label>
                      {formData.dateType === 'Custom Date' && (
                        <input
                          type="date"
                          name="customDate"
                          value={formData.customDate}
                          onChange={handleInputChange}
                          className="px-3 py-1.5 rounded-lg border border-stone-300 text-xs sm:text-sm focus:border-orange-500 min-h-[44px]"
                        />
                      )}
                    </div>
                  </div>

                  {/* Timing Window */}
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">
                      Preferred Muhurat Window
                    </label>
                    <select
                      name="timeWindow"
                      value={formData.timeWindow}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-stone-300 text-sm font-medium text-stone-800 bg-white focus:border-orange-500 min-h-[48px]"
                    >
                      <option value="Morning Shubh Muhurat (7:00 AM – 10:30 AM)">Morning Shubh Muhurat (7:00 AM – 10:30 AM)</option>
                      <option value="Midday Abhijit Muhurat (11:30 AM – 1:30 PM)">Midday Abhijit Muhurat (11:30 AM – 1:30 PM)</option>
                      <option value="Evening Godhuli / Twilight (4:30 PM – 7:30 PM)">Evening Godhuli / Twilight (4:30 PM – 7:30 PM) — Recommended</option>
                      <option value="Late Evening Shastrokt (7:30 PM – 9:30 PM)">Late Evening Shastrokt (7:30 PM – 9:30 PM)</option>
                    </select>
                  </div>

                  {/* City & Locality */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1.5">
                        City / Service Area *
                      </label>
                      <select
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 rounded-xl border border-stone-300 text-sm font-medium text-stone-800 bg-white focus:border-orange-500 min-h-[48px]"
                        required
                      >
                        <option value="Noida">Noida (All Sectors)</option>
                        <option value="Greater Noida">Greater Noida &amp; Noida Extension</option>
                        <option value="Delhi (South)">Delhi (South / Central)</option>
                        <option value="Delhi (East/West/North)">Delhi (East / West / North / Dwarka)</option>
                        <option value="Gurugram">Gurugram (DLF, Golf Course, Sohna Rd)</option>
                        <option value="Ghaziabad">Ghaziabad (Indirapuram, Vaishali)</option>
                        <option value="Faridabad">Faridabad</option>
                        <option value="Online Video Worldwide">Online Video (NRI / Outside NCR)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1.5">
                        Locality / Society Name
                      </label>
                      <input
                        type="text"
                        name="locality"
                        value={formData.locality}
                        onChange={handleInputChange}
                        placeholder="e.g., Sector 62, ATS Village, DLF 4"
                        className="w-full px-4 py-3 rounded-xl border border-stone-300 text-sm text-stone-800 placeholder-stone-400 focus:border-orange-500 min-h-[48px]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 3: DEVOTEE DETAILS */}
              {currentStep === 3 && (
                <div className="space-y-6 animate-fadeIn">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1.5">
                        Host / Devotee Full Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="e.g., Rashmi Sharma"
                        required
                        className="w-full px-4 py-3 rounded-xl border border-stone-300 text-sm text-stone-800 placeholder-stone-400 focus:border-orange-500 min-h-[48px]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1.5">
                        WhatsApp Contact Number *
                      </label>
                      <div className="flex">
                        <span className="inline-flex items-center px-3 rounded-l-xl border border-r-0 border-stone-300 bg-stone-50 text-stone-600 text-sm font-semibold">
                          +91
                        </span>
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="98765 43210"
                          maxLength={10}
                          required
                          className="w-full px-4 py-3 rounded-r-xl border border-stone-300 text-sm text-stone-800 placeholder-stone-400 focus:border-orange-500 min-h-[48px]"
                        />
                      </div>
                      <span className="text-[11px] text-stone-400 mt-1 block">
                        We send your itemized quote &amp; checklist to this WhatsApp number.
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1.5">
                        Email Address (Optional)
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="yourname@domain.com"
                        className="w-full px-4 py-3 rounded-xl border border-stone-300 text-sm text-stone-800 placeholder-stone-400 focus:border-orange-500 min-h-[48px]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1.5">
                        Family Gotra (Optional)
                      </label>
                      <input
                        type="text"
                        name="gotra"
                        value={formData.gotra}
                        onChange={handleInputChange}
                        placeholder="e.g., Kashyap, Bharadwaj, or Not Sure"
                        className="w-full px-4 py-3 rounded-xl border border-stone-300 text-sm text-stone-800 placeholder-stone-400 focus:border-orange-500 min-h-[48px]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-stone-500 mb-1.5">
                      Language &amp; Explanation Comfort
                    </label>
                    <select
                      name="language"
                      value={formData.language}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 rounded-xl border border-stone-300 text-sm font-medium text-stone-800 bg-white focus:border-orange-500 min-h-[48px]"
                    >
                      <option value="Hindi & Sanskrit with English explanation">Hindi &amp; Sanskrit with English explanation (Family-friendly)</option>
                      <option value="Pure Shastrokt Hindi & Sanskrit">Traditional Hindi &amp; Sanskrit</option>
                      <option value="English explanations for children/youth">Primarily English commentary with Sanskrit mantras</option>
                      <option value="Regional Customs (Braj / Mithila / Gujarati / South Indian)">Regional customs matching</option>
                    </select>
                  </div>
                </div>
              )}

              {/* STEP 4: REVIEW & CONFIRM */}
              {currentStep === 4 && (
                <div className="space-y-6 animate-fadeIn">
                  <div className="p-4 rounded-xl bg-orange-50/70 border border-orange-200 text-stone-800 space-y-3">
                    <div className="flex items-center justify-between border-b border-orange-200/60 pb-2">
                      <span className="font-heading font-bold text-base text-orange-950">
                        Priority Request Summary
                      </span>
                      <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                        100% Free Review
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 text-xs sm:text-sm">
                      <div><strong className="text-stone-600">Service:</strong> {formData.service}</div>
                      <div><strong className="text-stone-600">Mode:</strong> {formData.mode}</div>
                      <div><strong className="text-stone-600">Location:</strong> {formData.city} {formData.locality ? `(${formData.locality})` : ''}</div>
                      <div><strong className="text-stone-600">Date:</strong> {formData.dateType === 'Custom Date' ? formData.customDate : formData.dateType}</div>
                      <div><strong className="text-stone-600">Timing:</strong> {formData.timeWindow}</div>
                      <div><strong className="text-stone-600">Samagri:</strong> {formData.samagriPath}</div>
                      <div><strong className="text-stone-600">Devotee:</strong> {formData.name}</div>
                      <div><strong className="text-stone-600">WhatsApp:</strong> +91 {formData.phone}</div>
                      {formData.havanAddon && <div className="text-orange-800 font-medium">✓ Low-smoke havan requested</div>}
                    </div>

                    <div className="mt-4 pt-3 border-t border-orange-200 flex items-center justify-between text-sm font-bold text-stone-900">
                      <span>Total Amount to Pay Now:</span>
                      <span className="text-emerald-700 text-base">₹0.00 (Zero Upfront)</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-stone-100 text-xs text-stone-600 leading-relaxed">
                    By clicking <strong>Submit Priority Request</strong>, your details are sent directly to our Acharya-led booking desk. We will verify Pandit availability for your location within 30–60 minutes, share the complete itemized quote and preparation checklist on WhatsApp. You decide whether to proceed after reviewing the quote.
                  </div>
                </div>
              )}

              {/* Wizard Nav Buttons */}
              <div className="pt-4 flex items-center justify-between border-t border-stone-200 gap-4">
                {currentStep > 1 ? (
                  <button
                    type="button"
                    onClick={handlePrev}
                    className="px-5 py-3 rounded-xl border border-stone-300 text-stone-700 hover:bg-stone-50 font-semibold text-sm transition-all min-h-[48px]"
                  >
                    ← Back
                  </button>
                ) : <div />}

                {currentStep < 4 ? (
                  <button
                    type="button"
                    onClick={handleNext}
                    className="px-8 py-3 rounded-xl bg-gradient-to-r from-orange-600 to-amber-700 hover:from-orange-700 hover:to-amber-800 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all min-h-[48px]"
                  >
                    <span>Continue to Step {currentStep + 1}</span>
                    <span className="ml-1.5 font-bold">→</span>
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-bold text-base shadow-lg hover:shadow-xl transition-all min-h-[48px]"
                  >
                    <span>Submit Priority Request &amp; Open WhatsApp</span>
                    <span className="ml-2 font-bold">✓</span>
                  </button>
                )}
              </div>

            </form>
          )}

        </div>

        {/* Surrounding Trust Box */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-stone-600">
          <div className="bg-white p-4 rounded-xl border border-orange-100 flex items-start gap-2.5">
            <span className="text-lg">🛡️</span>
            <div>
              <strong className="text-stone-900 block font-heading">Zero Blind Payment Risk</strong>
              Request review is 100% free. Pay only after you approve the itemized quote.
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-orange-100 flex items-start gap-2.5">
            <span className="text-lg">💬</span>
            <div>
              <strong className="text-stone-900 block font-heading">Direct WhatsApp Desk</strong>
              Instant human coordination with Pandit desk at +91 75993 40430.
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl border border-orange-100 flex items-start gap-2.5">
            <span className="text-lg">🕊️</span>
            <div>
              <strong className="text-stone-900 block font-heading">Ethical Sanatan Vidhi</strong>
              Devotional celebration; no superstition, fear claims, or miracle guarantees.
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
export default PriorityRequestForm;
