import React from 'react';

export const DevoteeReviews: React.FC = () => {
  const reviews = [
    {
      name: "Smt. Rashmi & Rajesh Sharma",
      location: "Sector 62, Noida",
      date: "Kartik Devuthani Ekadashi",
      ritual: "Home Sanctum Tulsi Vivah with Path B Samagri",
      comment:
        "Booking a Pandit during peak Ekadashi used to be nerve-wracking. Shastriya Vidhan verified Pandit Ji's availability within 40 minutes and shared the exact quote with no hidden charges. Pandit Ji arrived 15 minutes before the muhurat, set up the Ganne ka Mandap so respectfully, and explained every mantra in Hindi so our children listened with keen devotion.",
      stars: 5,
    },
    {
      name: "Anand & Meenakshi Malhotra",
      location: "DLF Phase 4, Gurugram",
      date: "Kartik Shukla Dwadashi",
      ritual: "Apartment Home Puja with Low-Smoke Havan",
      comment:
        "Living in a high-rise, we were concerned about havan smoke and rushed rituals. The booking coordinator reassured us about the compact copper havan kund. Pandit Ji performed the Tulsi-Shaligram Vivah with utmost calm and grace, guiding us through the Kanyadaan without rushing through the Sanskrit slokas. Truly authentic Shastrokt vidhi.",
      stars: 5,
    },
    {
      name: "Virender Saxena & Family",
      location: "Greater Kailash 2, South Delhi",
      date: "Kartik Month Observance",
      ritual: "Traditional Home Vivah (Path A - Family Samagri)",
      comment:
        "The best part was their Request-First approach. We weren't forced to pay instantly online. We received the itemized samagri checklist in advance, arranged our household items easily, and only confirmed once we reviewed the quote. Pandit Ji's recitation of the Tulsi Vivah Katha brought tears of devotion to my mother's eyes.",
      stars: 5,
    },
    {
      name: "Dr. Priyamvada & Karthik Raman",
      location: "San Jose, California (NRI Family)",
      date: "Kartik Purnima",
      ritual: "Interactive HD Video Guided Puja",
      comment:
        "Being far away from India, we wanted our young kids to experience the beauty of Tulsi Vivah. Shastriya Vidhan coordinated the exact US Pacific timing window, sent a simple US grocery list for offerings, and conducted a 75-minute live interactive video ceremony. Pandit Ji's English explanations made the ritual unforgettable for our teenagers.",
      stars: 5,
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-white border-b border-orange-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-amber-800 bg-amber-100/80 px-3.5 py-1.5 rounded-full border border-amber-300">
            Real Devotee Experiences
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-4 mb-4 tracking-tight">
            Trusted by Families Across Noida, Delhi, Gurugram &amp; NRI Homes
          </h2>
          <p className="text-stone-600 text-base leading-relaxed">
            Read how devout families experienced calm, punctuality, and pure spiritual reverence during Kartik month with Shastriya Vidhan.
          </p>
        </div>

        {/* 4 Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {reviews.map((rev, idx) => (
            <div
              key={idx}
              className="bg-stone-50/70 rounded-2xl p-6 sm:p-7 border border-orange-200/80 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                {/* Header: Stars & Location */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1 text-amber-500">
                    {[...Array(rev.stars)].map((_, i) => (
                      <span key={i} className="text-base">★</span>
                    ))}
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-white text-stone-600 border border-stone-200">
                    {rev.location}
                  </span>
                </div>

                {/* Ritual Type Tag */}
                <div className="text-xs font-medium text-orange-700 mb-3">
                  {rev.ritual} • <span className="text-stone-500">{rev.date}</span>
                </div>

                {/* Testimonial Quote */}
                <p className="text-sm text-stone-700 leading-relaxed italic">
                  &ldquo;{rev.comment}&rdquo;
                </p>
              </div>

              {/* Devotee Info */}
              <div className="mt-6 pt-4 border-t border-stone-200/70 flex items-center justify-between">
                <div>
                  <div className="font-heading font-bold text-stone-900 text-sm">
                    {rev.name}
                  </div>
                  <div className="text-[11px] text-stone-500">Verified Devotee Booking</div>
                </div>
                <span className="text-xs text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md font-semibold border border-emerald-200">
                  ✓ Verified Puja
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Social Proof Trust Bar */}
        <div className="mt-12 p-6 rounded-2xl bg-gradient-to-r from-orange-50 via-amber-50 to-orange-50 border border-orange-200 text-center flex flex-col sm:flex-row items-center justify-around gap-4 text-xs sm:text-sm text-stone-700">
          <div className="flex items-center gap-2">
            <span className="text-orange-600 font-bold text-lg">4.9 / 5.0</span>
            <span>Family Satisfaction Rating</span>
          </div>
          <div className="h-4 w-px bg-orange-300 hidden sm:block" />
          <div className="flex items-center gap-2">
            <span className="text-orange-600 font-bold text-lg">100%</span>
            <span>Manual Schedule &amp; Muhurat Check</span>
          </div>
          <div className="h-4 w-px bg-orange-300 hidden sm:block" />
          <div className="flex items-center gap-2">
            <span className="text-orange-600 font-bold text-lg">0</span>
            <span>Payment Collected Before Quote Review</span>
          </div>
        </div>

      </div>
    </section>
  );
};
export default DevoteeReviews;
