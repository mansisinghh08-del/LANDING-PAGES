import { redirect } from 'next/navigation';

export default function HomePage() {
  redirect('/book-pandit-ji-online-for-tulsi-vivah');
}
