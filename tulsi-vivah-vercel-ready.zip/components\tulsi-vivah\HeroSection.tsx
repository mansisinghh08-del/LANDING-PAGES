import React from 'react';
import Image from 'next/image';

export const HeroSection: React.FC = () => {
  const valuePills = [
    { icon: "📅", text: "Manual Availability & Muhurat Check" },
    { icon: "🏡", text: "Home Visit (Delhi NCR) & Online Video Modes" },
    { icon: "📋", text: "Clear Samagri Checklist Shared Upfront" },
    { icon: "🛡️", text: "No Payment Before Quote Clarity" },
    { icon: "🗣️", text: "Hindi, Sanskrit & English Guidance" },
    { icon: "🙏", text: "Family-Friendly Step-by-Step Vidhi" },
  ];

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-amber-50/60 via-orange-50/30 to-white pt-8 pb-16 lg:pt-12 lg:pb-24 border-b border-orange-100/60">
      {/* Background Decorative Glow */}
      <div className="absolute top-0 right-1/4 -z-10 w-96 h-96 bg-amber-200/30 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 -z-10 w-80 h-80 bg-orange-200/20 rounded-full blur-2xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Core Value Proposition */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Top Trust Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-100/80 border border-amber-300 text-amber-900 text-xs sm:text-sm font-semibold tracking-wide shadow-sm">
              <span className="w-2 h-2 rounded-full bg-orange-600 animate-ping" />
              <span>Request-First Puja Booking • No Payment Before Quote Clarity</span>
            </div>

            {/* H1 Heading */}
            <h1 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight leading-[1.15]">
              Book Pandit Ji Online for <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 via-amber-700 to-red-800">Tulsi Vivah Puja</span> at Home or Online
            </h1>

            {/* Emotional & Clear Subheadline */}
            <p className="text-base sm:text-lg text-stone-600 leading-relaxed max-w-2xl font-normal">
              Celebrate the sacred union of Tulsi Mata and Lord Shaligram this Kartik month with experienced Vedic Pandits. Get complete vidhi guidance, upfront samagri checklists, and confirmed slot availability across Noida, Delhi, Gurugram, Ghaziabad &amp; Online before you pay.
            </p>

            {/* Quick Value Pills (6 Badges) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
              {valuePills.map((pill, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2.5 p-2 rounded-lg bg-white/90 border border-orange-100/90 shadow-sm text-xs sm:text-sm text-stone-700 font-medium"
                >
                  <span className="text-base shrink-0">{pill.icon}</span>
                  <span>{pill.text}</span>
                </div>
              ))}
            </div>

            {/* Dual High-Contrast CTAs */}
            <div className="pt-4 flex flex-col sm:flex-row gap-4 items-stretch sm:items-center">
              {/* Primary Anchor CTA */}
              <a
                href="#book-pandit-ji"
                className="inline-flex items-center justify-center px-7 py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-700 hover:from-orange-700 hover:to-amber-800 text-white font-bold text-base shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5 text-center min-h-[48px]"
              >
                <span>Request Exact Quote &amp; Availability</span>
                <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
              </a>

              {/* Secondary WhatsApp CTA */}
              <a
                href="https://wa.me/917599340430?text=Namaste%20Shastriya%20Vidhan%2C%20I%20want%20to%20book%20a%20Pandit%20Ji%20for%20Tulsi%20Vivah%20Puja.%20Please%20share%20availability%20and%20quote."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-base shadow-md hover:shadow-lg transition-all min-h-[48px]"
              >
                <svg className="w-5 h-5 mr-2 fill-current" viewBox="0 0 24 24">
                  <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981z" />
                </svg>
                <span>WhatsApp Booking Desk</span>
              </a>
            </div>

            {/* Direct Phone Assistance Note */}
            <div className="pt-1 text-xs sm:text-sm text-stone-500 flex items-center gap-2">
              <span>Prefer speaking directly?</span>
              <a href="tel:+917599340430" className="font-semibold text-orange-700 hover:underline">
                Call +91 75993 40430
              </a>
              <span className="text-stone-400">• Available 7 AM – 9:30 PM</span>
            </div>
          </div>

          {/* Right Column: Visual Card with Next/Image and Priority */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl p-2.5 bg-gradient-to-tr from-amber-200/60 via-orange-100 to-amber-100 border border-orange-200/80 shadow-vedic-lg">
              <div className="relative h-[360px] sm:h-[440px] w-full rounded-xl overflow-hidden shadow-md">
                <Image
                  src="/images/tulsi-vivah.webp"
                  alt="Book Pandit Ji Online for Tulsi Vivah Puja - Authentic Tulsi Shaligram Vivah Arrangement"
                  fill
                  priority
                  className="object-cover object-center"
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 40vw"
                />
                
                {/* Subtle Gradient Overlay for Depth */}
                <div className="absolute inset-0 bg-gradient-to-t from-stone-900/60 via-transparent to-transparent pointer-events-none" />

                {/* Top Corner Badge */}
                <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-amber-950 border border-amber-200 shadow-sm">
                  Shastrokt Vivah Vidhi
                </div>

                {/* Bottom Floating Trust Card */}
                <div className="absolute bottom-3 left-3 right-3 bg-white/95 backdrop-blur-md rounded-xl p-3 border border-orange-200/80 shadow-md text-stone-800">
                  <div className="flex items-center justify-between text-xs font-bold text-orange-700 mb-1">
                    <span className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      Typical Duration: 60–120 Mins
                    </span>
                    <span className="text-stone-500 font-normal">Acharya Verified</span>
                  </div>
                  <p className="text-xs text-stone-600 font-medium leading-tight">
                    <span className="font-semibold text-stone-900">Verified Request Areas:</span> Noida • Delhi • Gurugram • Ghaziabad • Online Worldwide
                  </p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
export default HeroSection;
