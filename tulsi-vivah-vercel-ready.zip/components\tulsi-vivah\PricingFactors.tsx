import React from 'react';

export const PricingFactors: React.FC = () => {
  const costFactors = [
    {
      factor: "City & Travel Distance",
      detail: "Direct home visits across Noida, Greater Noida, Delhi, Gurugram, and Ghaziabad. Distance from local Pandit sanctum influences modest travel logistics.",
      impact: "Transparently calculated based on sector/locality",
    },
    {
      factor: "Date & Muhurat Window",
      detail: "Demand peaks on Devuthani Ekadashi and Kartik Purnima day. Morning, twilight, and evening muhurat windows are matched to Pandit availability.",
      impact: "Standardized festive schedule; early request locks slot",
    },
    {
      factor: "Pandit Count",
      detail: "Standard Tulsi Vivah is led by 1 experienced Vedic Pandit Ji. Larger community, temple, or society celebrations can request 2 or more Pandits.",
      impact: "1 Pandit (Standard Family) or 2+ (Society/Grand)",
    },
    {
      factor: "Ceremony Duration",
      detail: "Standard complete vidhi lasts between 60 to 120 minutes. Extended chanting (Vishnu Sahasranama) or detailed katha can be customized.",
      impact: "60 mins (Compact) to 120 mins (Full Shastrokt)",
    },
    {
      factor: "Samagri Scope (Path A vs Path B)",
      detail: "Choose between Path A (Family arranges items with our checklist) or Path B (Pandit Ji brings complete coordinated puja kit & Ganne ka Mandap).",
      impact: "Family Prepared (Guidance Only) vs Full Kit Support",
    },
    {
      factor: "Puja Venue Format",
      detail: "Private apartment or villa in Delhi NCR, residential society clubhouse, or live interactive two-way HD video session for NRI devotees abroad.",
      impact: "Home Visit (NCR) vs Online Global Video Session",
    },
    {
      factor: "Havan & Chanting Add-ons",
      detail: "Optional low-smoke copper kund havan (apartment safe) or specialized sankalp extensions requested by the family.",
      impact: "Added as an itemized, optional choice",
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-amber-50/40 border-b border-orange-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-orange-800 bg-orange-100 px-3.5 py-1.5 rounded-full border border-orange-200">
            Honest &amp; Itemized Transparency
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-4 mb-4 tracking-tight">
            Tulsi Vivah Puja Cost &amp; Quote Factors
          </h2>
          <p className="text-stone-600 text-base leading-relaxed">
            Unlike commercial platforms that charge arbitrary upfront flat fees, Shastriya Vidhan provides a customized, transparent quote based strictly on your family’s ceremony requirements.
          </p>
        </div>

        {/* 2 Clear Booking Paths */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-14">
          
          {/* Path A */}
          <div className="bg-white rounded-2xl p-7 border-2 border-orange-200 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-stone-100 text-stone-700">
                  Path A • Traditional
                </span>
                <span className="text-xl">🧺</span>
              </div>
              <h3 className="font-heading text-xl font-bold text-stone-900 mb-2">
                Pandit Ji Guidance Only
              </h3>
              <div className="text-xs font-semibold text-orange-700 uppercase tracking-wide mb-3">
                Family Arranges Samagri
              </div>
              <p className="text-sm text-stone-600 leading-relaxed mb-4">
                Ideal for families who cherish preparing sacred offerings at home. We provide our comprehensive, itemized checklist of fruits, flowers, sugarcane stalks, and household puja items ahead of time.
              </p>
              <ul className="space-y-2 text-xs sm:text-sm text-stone-700 mb-6">
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span>Screened Vedic Pandit Ji arrival at home</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span>Complete Shastrokt Vidhi, Katha &amp; Aarti (60–120 mins)</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span>Itemized preparation checklist shared immediately</span>
                </li>
              </ul>
            </div>
            <a
              href="#book-pandit-ji"
              className="w-full text-center py-2.5 rounded-xl border border-orange-300 bg-orange-50 hover:bg-orange-100 text-orange-900 font-semibold text-sm transition-all"
            >
              Request Path A Quote
            </a>
          </div>

          {/* Path B */}
          <div className="bg-white rounded-2xl p-7 border-2 border-orange-500 shadow-md flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-gradient-to-l from-orange-600 to-amber-600 text-white text-[11px] font-bold px-3 py-1 rounded-bl-lg">
              Most Popular for Working Families
            </div>
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-orange-100 text-orange-800">
                  Path B • Complete Ease
                </span>
                <span className="text-xl">✨</span>
              </div>
              <h3 className="font-heading text-xl font-bold text-stone-900 mb-2">
                Pandit Ji + Coordinated Samagri Support
              </h3>
              <div className="text-xs font-semibold text-amber-700 uppercase tracking-wide mb-3">
                Zero Market Hassle
              </div>
              <p className="text-sm text-stone-600 leading-relaxed mb-4">
                Ideal for busy working families in Noida, Delhi, Gurugram &amp; Ghaziabad. Pandit Ji coordinates and brings the specialized ritual kit (sacred suhaag items, gathbandhan, kalash items, and authentic Shaligram Shila if needed).
              </p>
              <ul className="space-y-2 text-xs sm:text-sm text-stone-700 mb-6">
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span>Everything in Path A plus verified authentic ritual items</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span>Ganne ka Mandap setup assistance &amp; suhaag adornments</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-emerald-600 font-bold">✓</span>
                  <span>Family only prepares simple fresh fruits &amp; home milk</span>
                </li>
              </ul>
            </div>
            <a
              href="#book-pandit-ji"
              className="w-full text-center py-2.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-700 hover:from-orange-700 hover:to-amber-800 text-white font-semibold text-sm shadow-sm transition-all"
            >
              Request Path B Quote
            </a>
          </div>

        </div>

        {/* Clean 7-Row Table Explaining Cost Factors */}
        <div className="bg-white rounded-2xl border border-orange-200 shadow-sm overflow-hidden">
          <div className="p-5 bg-gradient-to-r from-orange-50 to-amber-50 border-b border-orange-200">
            <h3 className="font-heading text-lg font-bold text-stone-900">
              The 7 Factors That Determine Your Quote
            </h3>
            <p className="text-xs text-stone-600 mt-0.5">
              Every quote is customized and shared for review before you pay a single rupee
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead>
                <tr className="border-b border-orange-100 bg-stone-50/60 text-xs font-bold text-stone-700 uppercase tracking-wider">
                  <th className="py-3 px-5 w-1/4">Cost Factor</th>
                  <th className="py-3 px-5 w-1/2">Service Detail &amp; Scope</th>
                  <th className="py-3 px-5 w-1/4">Quote Impact</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-orange-100/70 text-xs sm:text-sm">
                {costFactors.map((row, idx) => (
                  <tr key={idx} className="hover:bg-amber-50/20 transition-colors">
                    <td className="py-3.5 px-5 font-bold text-stone-900">
                      {row.factor}
                    </td>
                    <td className="py-3.5 px-5 text-stone-600 leading-relaxed">
                      {row.detail}
                    </td>
                    <td className="py-3.5 px-5 font-medium text-orange-800 bg-orange-50/20">
                      {row.impact}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </section>
  );
};
export default PricingFactors;
