import React from 'react';
import Link from 'next/link';

export const PreparationGuidesStrip: React.FC = () => {
  const guides = [
    {
      title: "Kartik Month & Devuthani Muhurat",
      desc: "Check auspicious tithi windows & sunset vivah timings.",
      href: "/guides#festival-guides",
      icon: "📅",
    },
    {
      title: "Tulsi Vivah Samagri Checklist",
      desc: "Review standard household vs. arranged ritual items.",
      href: "/guides#samagri-guidance",
      icon: "📋",
    },
    {
      title: "Home Sanctum Setup Guide",
      desc: "How to arrange the altar, mandap, and seating space.",
      href: "/guides#puja-preparation",
      icon: "🪔",
    },
    {
      title: "Noida & Delhi NCR Coverage",
      desc: "Pandit Ji availability across Noida, Delhi & Gurugram.",
      href: "/locations/noida",
      icon: "📍",
    },
  ];

  return (
    <section className="py-12 bg-amber-50/50 border-b border-orange-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-orange-800 bg-orange-100 px-3 py-1 rounded-full">
              Helpful Preparation Guides
            </span>
            <h3 className="font-heading text-xl sm:text-2xl font-bold text-stone-900 mt-2">
              Preparing for Your Home Tulsi Vivah
            </h3>
          </div>
          <p className="text-xs sm:text-sm text-stone-600 max-w-md">
            Need guidance on tithi timings or household preparation before booking? Explore our dedicated resource hubs.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {guides.map((g, idx) => (
            <Link
              key={idx}
              href={g.href}
              className="p-4 rounded-xl bg-white border border-orange-200/80 hover:border-orange-400 hover:shadow-md transition-all group flex items-start gap-3 min-h-[48px]"
            >
              <span className="text-2xl shrink-0 group-hover:scale-110 transition-transform">
                {g.icon}
              </span>
              <div>
                <h4 className="font-heading font-bold text-stone-900 text-sm group-hover:text-orange-700 transition-colors">
                  {g.title}
                </h4>
                <p className="text-xs text-stone-500 mt-0.5 leading-snug">
                  {g.desc}
                </p>
                <span className="text-[11px] font-semibold text-orange-600 mt-1.5 inline-flex items-center gap-1 group-hover:underline">
                  Read guide →
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};
export default PreparationGuidesStrip;
