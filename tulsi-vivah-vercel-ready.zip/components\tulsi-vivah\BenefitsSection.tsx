import React from 'react';

export const BenefitsSection: React.FC = () => {
  const benefits = [
    {
      benefit: "Complete Devotional Participation",
      explanation:
        "Pandit Ji guides your family through each ritual step with patience—including the personalized Parivar Sankalp, Ganesh-Ambika worship, Shaligram-Tulsi sacred abhishek, traditional wedding ceremony (gathbandhan, kanyadaan, mangalashtak), sacred katha, and aarti.",
      outcome: "Every generation in your home—from elderly grandparents to curious children—feels connected, respected, and spiritually involved.",
      icon: "🌺",
    },
    {
      benefit: "Zero Preparation Anxiety",
      explanation:
        "Immediately upon request review, our booking coordinator shares a customized, itemized samagri checklist detailing household items versus arranged items, along with sanctum setup tips for modern apartments and villas.",
      outcome: "No last-minute market runs before the muhurat and no frantic second-guessing on the day of the puja.",
      icon: "✨",
    },
    {
      benefit: "Flexible Home or Online Formats",
      explanation:
        "Opt for in-person home visits conducted by punctual Vedic priests across Noida, Delhi, Gurugram & Ghaziabad, or join an interactive HD live video ceremony if you are an NRI devotee or reside outside NCR.",
      outcome: "Celebrate the sacred wedding of Tulsi Devi authentically according to Shastrokt Vidhi, wherever your family lives.",
      icon: "🏡",
    },
    {
      benefit: "Complete Pricing Transparency",
      explanation:
        "We itemize every single cost factor upfront—including city travel, duration (60–120 mins), samagri coordination scope, and optional havan add-ons—before you confirm.",
      outcome: "100% peace of mind with guaranteed clarity and zero awkward post-puja bargaining or unexpected demands.",
      icon: "⚖️",
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-amber-50/40 border-b border-orange-100/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-orange-800 bg-orange-100 px-3.5 py-1.5 rounded-full border border-orange-200">
            Devotional Value &amp; Peace of Mind
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-4 mb-4 tracking-tight">
            What Your Family Experiences When You Book With Shastriya Vidhan
          </h2>
          <p className="text-stone-600 text-base leading-relaxed">
            Every aspect of our service is designed to preserve the sanctity of the ritual while removing worldly stress for the host family.
          </p>
        </div>

        {/* 4 Structured Benefit Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {benefits.map((card, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-6 sm:p-8 border border-orange-200/90 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Benefit Header */}
                <div className="flex items-center gap-3 pb-2 border-b border-orange-100">
                  <span className="text-2xl">{card.icon}</span>
                  <div>
                    <div className="text-xs font-bold text-orange-600 uppercase tracking-wider flex items-center gap-1">
                      <span>✔</span> Verified Benefit
                    </div>
                    <h3 className="font-heading text-lg sm:text-xl font-bold text-stone-900">
                      {card.benefit}
                    </h3>
                  </div>
                </div>

                {/* Supporting Explanation */}
                <div className="text-sm text-stone-600 leading-relaxed">
                  <span className="font-semibold text-stone-800">Ceremonial Vidhi: </span>
                  {card.explanation}
                </div>
              </div>

              {/* Family Outcome Pill */}
              <div className="mt-6 pt-4 bg-orange-50/70 rounded-xl p-3.5 border border-orange-200/60 text-xs sm:text-sm text-amber-950 font-medium">
                <span className="font-bold text-orange-700">Family Outcome: </span>
                <span>{card.outcome}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
export default BenefitsSection;
