import React from 'react';

export const CeremonialInclusions: React.FC = () => {
  const inclusions = [
    {
      step: "01",
      title: "Swasti Vachan & Parivar Sankalp",
      description:
        "The ceremony opens with sacred Vedic Swasti Vachan invocations and a personalized family Sankalp, reciting the family's Gotra, names, and devotional intentions for peace, auspiciousness, and spiritual well-being.",
      icon: "🕉️",
      tag: "Core Ritual",
    },
    {
      step: "02",
      title: "Ganesh-Gauri & Kalash Sthapana",
      description:
        "Invoking Lord Ganesha (Vighnaharta) and Devi Gauri for obstacle-free observance, accompanied by the traditional Vedic Mangal Kalash Sthapana filled with sacred water, betel nuts, coins, and mango leaves.",
      icon: "🏺",
      tag: "Core Ritual",
    },
    {
      step: "03",
      title: "Shaligram & Tulsi Mata Worship",
      description:
        "Shodashopachara (16-step) worship of both deities: ritual abhishek of Lord Shaligram with panchamrit/gangajal, sacred tilak, decorating Tulsi Mata in a bridal red chunri, suhaag items, and fragrant flower garlands.",
      icon: "🌿",
      tag: "Core Ritual",
    },
    {
      step: "04",
      title: "Traditional Vivah Vidhi & Kanyadaan",
      description:
        "The ceremonial divine marriage featuring the sacred Gathbandhan (tying the yellow and red nuptial knot), Mangalashtak and Vedic wedding mantra chanting, symbolic Kanyadaan ritual, and offering of auspicious sindoor and suhaag samagri.",
      icon: "🪢",
      tag: "Sacred Highlight",
    },
    {
      step: "05",
      title: "Tulsi Vivah Katha & Family Aarti",
      description:
        "Recitation of the sacred Kartik Tulsi Vivah Katha (the divine story of Vrinda and Lord Vishnu), offering of sweet bhog/prasad, chanting of Kshama Prarthana (seeking forgiveness for unintended omissions), and collective family Maha Aarti.",
      icon: "🪔",
      tag: "Sacred Highlight",
    },
    {
      step: "06",
      title: "Custom Add-Ons & Adaptations",
      description:
        "Optional extensions customized for your home: complete coordinated samagri kit (including Ganne ka Mandap), apartment-safe compact copper kund havan, or extended Vishnu Sahasranama / devotional bhajan recitation.",
      icon: "✨",
      tag: "Optional Add-Ons",
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-white border-b border-orange-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12 sm:mb-16">
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-amber-800 bg-amber-100/80 px-3.5 py-1.5 rounded-full border border-amber-300">
            Shastrokt Ceremonial Flow
          </span>
          <h2 className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold text-stone-900 mt-4 mb-4 tracking-tight">
            What Is Included in Our Tulsi Vivah Puja Service
          </h2>
          <p className="text-stone-600 text-base leading-relaxed">
            Every step is conducted strictly in accordance with Vedic scriptures and Sanatan tradition, ensuring your family partakes in an authentic and spiritually uplifting divine marriage celebration.
          </p>
        </div>

        {/* 6 Clean Icon Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {inclusions.map((item, idx) => (
            <div
              key={idx}
              className="bg-stone-50/70 hover:bg-white rounded-2xl p-6 sm:p-7 border border-orange-200/80 hover:border-orange-300 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-orange-100/80 border border-orange-200 flex items-center justify-center text-2xl">
                    {item.icon}
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-white text-stone-600 border border-stone-200">
                    Step {item.step}
                  </span>
                </div>

                <div className="mb-2">
                  <span className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                    item.tag === 'Core Ritual' 
                      ? 'bg-amber-100 text-amber-800' 
                      : item.tag === 'Sacred Highlight' 
                      ? 'bg-rose-100 text-rose-800' 
                      : 'bg-stone-200 text-stone-700'
                  }`}>
                    {item.tag}
                  </span>
                </div>

                <h3 className="font-heading text-lg font-bold text-stone-900 mb-2">
                  {item.title}
                </h3>
                <p className="text-sm text-stone-600 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-stone-200/60 flex items-center gap-1.5 text-xs text-orange-700 font-semibold">
                <span>Guided step-by-step by Pandit Ji</span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Note on Duration */}
        <div className="mt-12 p-4 rounded-xl bg-amber-50/80 border border-amber-200 text-center text-sm text-stone-700">
          <span className="font-bold text-amber-900">Ceremony Duration:</span> A standard home puja takes approximately <strong>60 to 120 minutes</strong> depending on family participation and whether optional Havan or extended Katha is requested.
        </div>

      </div>
    </section>
  );
};
export default CeremonialInclusions;
