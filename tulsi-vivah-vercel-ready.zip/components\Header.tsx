import React from 'react';
import Image from 'next/image';
import Link from 'next/link';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-orange-100 shadow-sm">
      {/* Top Notification Announcement Bar */}
      <div className="bg-gradient-to-r from-amber-700 via-orange-600 to-amber-800 text-white text-xs sm:text-sm py-1.5 px-4 text-center font-medium tracking-wide">
        <span className="inline-block mr-2 animate-pulse">✨</span>
        <span className="font-semibold">Devuthani Ekadashi &amp; Kartik Purnima Slots Open:</span> Pre-register early for verified Pandit Ji home visits across Noida, Delhi, Gurugram &amp; Ghaziabad.
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <Link href="/" className="flex items-center gap-3 group">
          <div className="relative w-44 sm:w-56 h-12">
            <Image
              src="/images/shastriya-vidhan-logo.png"
              alt="Shastriya Vidhan - Authentic Vedic Pandit Services"
              fill
              className="object-contain object-left"
              priority
            />
          </div>
        </Link>

        {/* Quick Trust Badges & Contact Endpoints */}
        <div className="flex items-center gap-3 sm:gap-6">
          <div className="hidden lg:flex flex-col text-right">
            <span className="text-xs uppercase font-bold tracking-wider text-amber-900/70">Request-First Booking</span>
            <span className="text-xs text-gray-500">No payment before quote clarity</span>
          </div>

          {/* Direct Phone Call Button */}
          <a
            href="tel:+917599340430"
            className="flex items-center gap-2 px-3 sm:px-4 py-2.5 rounded-full border border-orange-200 bg-orange-50/80 hover:bg-orange-100/80 text-amber-950 font-semibold text-xs sm:text-sm transition-all shadow-sm min-h-[48px]"
            title="Call Shastriya Vidhan Booking Desk"
          >
            <svg className="w-4 h-4 text-orange-600 shrink-0" fill="currentColor" viewBox="0 0 24 24">
              <path d="M6.62 10.79a15.053 15.053 0 006.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" />
            </svg>
            <span className="hidden sm:inline">+91 75993 40430</span>
            <span className="sm:hidden font-medium">Call Desk</span>
          </a>

          {/* Primary Quick CTA */}
          <a
            href="#book-pandit-ji"
            className="inline-flex items-center justify-center px-4 sm:px-6 py-2.5 rounded-full bg-gradient-to-r from-orange-600 to-amber-700 hover:from-orange-700 hover:to-amber-800 text-white font-semibold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all min-h-[48px]"
          >
            Check Availability
          </a>
        </div>
      </div>
    </header>
  );
};
export default Header;
