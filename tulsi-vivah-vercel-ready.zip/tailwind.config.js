/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        vedic: {
          saffron: "#E65100",
          "saffron-hover": "#C94400",
          "saffron-light": "#FFEDD5",
          "saffron-50": "#FFF7ED",
          maroon: "#800020",
          "maroon-dark": "#5C0017",
          "maroon-light": "#A31636",
          gold: "#D97706",
          "gold-light": "#FEF3C7",
          ivory: "#FFFDF9",
          surface: "#FAF6F0",
          card: "#FFFFFF",
          border: "#FED7AA",
          muted: "#6B7280",
          heading: "#1F2937",
        },
      },
      fontFamily: {
        heading: ["var(--font-outfit)", "Outfit", "sans-serif"],
        sans: ["var(--font-inter)", "Inter", "sans-serif"],
      },
      boxShadow: {
        vedic: "0 4px 20px -2px rgba(230, 81, 0, 0.08), 0 2px 6px -1px rgba(128, 0, 32, 0.04)",
        "vedic-lg": "0 10px 30px -4px rgba(230, 81, 0, 0.12), 0 4px 10px -2px rgba(128, 0, 32, 0.06)",
      },
    },
  },
  plugins: [],
};
